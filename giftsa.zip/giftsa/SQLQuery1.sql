Create Database myDB;




Create Table Users
(

	Number VARCHAR(11)  not null  primary key,
	Full_name VARCHAR(100),
	Birthday Date,
	CountryTimezone NVARCHAR(50)

);

